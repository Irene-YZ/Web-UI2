Social Media Sleek Icons: Icon Pack

http://designinstruct.com/free-resources/icons/social-media-sleek-icons-icon-pack/

Licensed Under Creative Commons

HTML code for attributing the work:<a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-sa/3.0/88x31.png" /></a><br /><span xmlns:dc="http://purl.org/dc/elements/1.1/" href="http://purl.org/dc/dcmitype/StillImage" property="dc:title" rel="dc:type">Social Media Sleek Icons</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="http://designinstruct.com/free-resources/icons/social-media-sleek-icons-icon-pack/" property="cc:attributionName" rel="cc:attributionURL">Design Instruct</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/">Creative Commons Attribution-ShareAlike 3.0 Unported License</a>.